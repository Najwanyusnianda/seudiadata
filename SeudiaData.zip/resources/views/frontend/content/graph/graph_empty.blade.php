<div class="card card-warning card-annoucement card-round">
    <div class="card-body text-center">
        <div class="card-opening">Data Tidak Ditemukan</div>
        <div class="card-desc">
Data tidak ditemukan untuk variabel ini 
        </div>
        <div class="card-detail">
            <a class="btn btn-light btn-rounded" href="{{ route('data.index') }}">Tambah Data</a>
        </div>
    </div>
</div>