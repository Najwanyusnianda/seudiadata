<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="card-head-row">
            <div class="card-title">User Statistics</div>
            <div class="card-tools">
            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-info btn-border btn-round btn-sm mr-2">
                    <span class="btn-label">
                        <i class="fa fa-plush"></i>
                    </span>
                    Tambah Pengguna
                </a>

            </div>
        </div>
    </div>
    <div class="card-body">
        <?php if($users->isEmpty()): ?>
            
        <?php else: ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Aksie</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->typeId==1 ? 'Superadmin' : ($user->typeId==2 ? 'admin' : 'operator')); ?></td>

                    <td>
                        <a href="<?php echo e(route('user.update',['user_id'=>$user->id])); ?>" class="btn btn-sm btn-success"> Update Data</a>
                        <a href="<?php echo e(route('user.delete',['user_id'=>$user->id])); ?>" class="btn btn-sm btn-danger"> Hapus Data</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </tbody>
        </table>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\APP DEVELOPMENT\web\SeudiaData\resources\views/backend/user_management/user_index.blade.php ENDPATH**/ ?>