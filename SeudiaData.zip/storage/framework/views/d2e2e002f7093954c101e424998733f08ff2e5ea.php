<?php $__env->startSection('page_header'); ?>
<h4 class="page-title">Daftar Subject</h4>
<ul class="breadcrumbs">
    <li class="nav-home">
        <a href="#">
            <i class="flaticon-home"></i>
        </a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="<?php echo e(route('data.index')); ?>">Daftar Subject</a>
    </li>


</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="card">
    <div class="card-header">
 Daftar  Subject 
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama Subject</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <span class="font-weight-bold"> <?php echo e($sb->subject_name); ?></span>
                           
                        </td>
                        <td>
                        <a href="<?php echo e(route('data.indicatorIndex',[$sb->id])); ?>" class="btn btn-sm btn-info" style="background-color:#0984e3 !important;"><i class="fas fa-chart-area"></i> Grafik</a>
                        <a href="<?php echo e(route('data.mapIndicatorIndex',[$sb->id])); ?>" class="btn btn-info btn-sm" style="background-color:#00b894 !important"><i class="far fa-map"></i> Peta</a>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
               
                <?php endif; ?>
            </tbody>
        </table>


    </div>
    <div class="card-footer">

    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\APP DEVELOPMENT\web\SeudiaData\resources\views/backend/data_management/input_data_indeks.blade.php ENDPATH**/ ?>