<div class="container">

    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Garis Kemiskinan</h4>
        </div>

        <div class="card-body">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut temporibus dicta eaque cumque excepturi dolores aut similique. Doloremque eos facilis saepe, possimus nihil vero ducimus aliquam velit temporibus, atque corrupti.
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Gini Ratio</h4>
        </div>
        <div class="card-body">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Et aliquam hic harum illo placeat numquam temporibus ratione provident illum doloribus. Doloremque aperiam sequi assumenda fugiat error nemo odit doloribus vel!   
        </div>
    </div>
</div>
<?php /**PATH D:\Project\APP DEVELOPMENT\web\SeudiaData\resources\views/frontend/kemiskinan/ulasan_kemiskinan.blade.php ENDPATH**/ ?>