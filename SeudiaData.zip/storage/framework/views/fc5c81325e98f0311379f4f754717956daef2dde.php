<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <?php if(empty($user)): ?>
                <h4>Tambah Pengguna Baru</h4>
                <?php else: ?>
                <h4>Update Data Pengguna</h4>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if(empty($user)): ?>
                <form action="<?php echo e(route('user.store')); ?>" method="post" >
                    <?php echo e(csrf_field()); ?>

     
                    <div class="form-group">
                        <label for="indikator">Nama</label>
                        <input type="indikator" class="form-control" id="name" name="name" value="">
                        <small id="emailHelp2" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="indikator">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="">
                        <small id="emailHelp2" class="form-text text-muted"></small>
                    </div>
                    
                    <div class="form-group">
                        <label for="indikator">Username</label>
                        <input type="text" class="form-control" id="username" name="username"  value="">
                        <small id="emailHelp2" class="form-text text-muted"></small>
                    </div>

                    <div class="form-group">
                        <label for="indikator">Password</label>
                        <input type="password" class="form-control" id="password" name="password"  value="">
                        <small id="emailHelp2" class="form-text text-muted"></small>
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Role </label>
                        <select class="form-control" id="role" name="role">
                            <option value="1" >Admin</option>
                            <option value="2" >Operator</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                <?php else: ?>
                <form action="<?php echo e(route('user.storeUpdate',[$user->id])); ?>" method="post" >
                    <?php echo e(csrf_field()); ?>

     
                    <div class="form-group">
                        <label for="indikator">Nama</label>
                        <input type="indikator" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
                        <small id="emailHelp2" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="indikator">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->username); ?>">
                        <small id="emailHelp2" class="form-text text-muted"></small>
                    </div>
                    
                    <div class="form-group">
                        <label for="indikator">Username</label>
                        <input type="text" class="form-control" id="username" name="username"  value="<?php echo e($user->email); ?>">
                        <small id="emailHelp2" class="form-text text-muted"></small>
                    </div>

                    <div class="form-group">
                        <label for="indikator">Password</label>
                        <input type="password" class="form-control" id="password" name="password"  value="">
                        <small id="emailHelp2" class="form-text text-muted"></small>
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Role </label>
                        <select class="form-control" id="role" name="role">
                            <option disabled >Pilih Role</option>
                            <option value="1"  <?php echo e($user->typeId==1 ? 'selected' : ''); ?>>Admin</option>
                            <option value="2" <?php echo e($user->typeId==2 ? 'selected' : ''); ?> >Operator</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                <?php endif; ?>

         

               
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\APP DEVELOPMENT\web\SeudiaData\resources\views/backend/user_management/user_create.blade.php ENDPATH**/ ?>