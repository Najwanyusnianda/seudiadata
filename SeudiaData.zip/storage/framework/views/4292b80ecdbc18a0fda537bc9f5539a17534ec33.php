<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block">
  <button type="button" class="close" data-dismiss="alert">×</button> 
    <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>
<?php if(!empty($indikator)): ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h4> Update Data Konten <?php echo e($indikator->indikator); ?></h4>
        </div>
        <div class="card-body">
        <form action="<?php echo e(route('data.update')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" class="form-control" id="indikator_id" name="indikator_id"  value="<?php echo e($indikator->id); ?>">
                <div class="form-group">
                    <label for="indikator">Indikator</label>
                    <input type="indikator" class="form-control" id="indikator" name="indikator"  value="<?php echo e($indikator->indikator); ?>">
                    <small id="emailHelp2" class="form-text text-muted"></small>
                </div>
                <div class="form-group">
                    <label for="graph_type">Tipe Visualisasi</label>
                    <select class="form-control" id="graph_type" name="graph_type">
                        <option selected disabled> Pilih Jenis Visualisasi</option>

                         <option value="Batang" <?php echo e($indikator->graph_type=='Batang' ? 'selected' : ''); ?>>Bar Chart (Batang)</option>
                         <option value="Garis"  <?php echo e($indikator->graph_type=='Garis' ? 'selected' : ''); ?>>Line Chart (Garis)</option>
                         <option value="pie_chart"  <?php echo e($indikator->graph_type=='pie_chart' ? 'selected' : ''); ?>>Pie Chart </option>

                    </select>
                    <small id="emailHelp2" class="form-text text-muted"></small>
                </div>
                <div class="form-group">
                    <label for="indikator">Judul Konten</label>
                    <input type="indikator" class="form-control" id="title" name="title"  value="<?php echo e($indikator->title); ?>">
                    <small id="emailHelp2" class="form-text text-muted"></small>
                </div>

                <div class="form-group">
                    <label for="indikator">Sub Judul Konten</label>
                <input type="indikator" class="form-control" id="subtitle" name="subtitle"  value="<?php echo e($indikator->subtitle); ?>">
                    <small id="emailHelp2" class="form-text text-muted"></small>
                </div>
                <div class="form-group">
                    <label for="data_file">Upload Data</label>
                    <input type="file" class="form-control-file" id="data_file" name="data_file">
                    <br>
                <a class="btn btn-info btn-sm" href="#" id="download_template">
                        <span class="btn-label">
                            <i class="fa fa-download"></i>
                        </span>
                        Download Template Data
                </a>
                
                </div>
                <div class="form-group">
                    <textarea name="ulasan" id="ulasan">
                        &lt;p&gt;This is some sample content.&lt;/p&gt;
                    </textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
     

           
        </div>
    </div>
</div>
<?php else: ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h4> Tambah Indikator Baru</h4>
        </div>
        <div class="card-body">
        <form action="<?php echo e(route('data.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="indikator">Subject</label>
                    <select class="form-control" id="subject" name="subject">
                        <option selected disabled> Pilih Variabel</option>
                        <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                         <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->subject_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </select>
                    <small id="emailHelp2" class="form-text text-muted"></small>
                </div>
                <input type="hidden" class="form-control" id="indikator_id" name="indikator_id"  value="">
                <div class="form-group">
                    <label for="indikator">Indikator</label>
                    <input type="indikator" class="form-control" id="indikator" name="indikator"  value="">
                    <small id="emailHelp2" class="form-text text-muted"></small>
                </div>
                <div class="form-group">
                    <label for="graph_type">Tipe Visualisasi</label>
                    <select class="form-control" id="graph_type" name="graph_type">
                        <option selected disabled> Pilih Jenis Visualisasi</option>

                         <option value="Batang">Bar Chart (Batang)</option>
                         <option value="Garis">Line Chart (Garis)</option>
                         <option value="pie_chart">Pie Chart </option>

                    </select>
                    <small id="emailHelp2" class="form-text text-muted"></small>
                </div>
                <div class="form-group">
                    <label for="indikator">Judul Konten</label>
                    <input type="indikator" class="form-control" id="title" name="title"  value="">
                    <small id="emailHelp2" class="form-text text-muted"></small>
                </div>

                <div class="form-group">
                    <label for="indikator">Sub Judul Konten</label>
                <input type="indikator" class="form-control" id="subtitle" name="subtitle"  value="">
                    <small id="emailHelp2" class="form-text text-muted"></small>
                </div>
                <div class="form-group">
                    <label for="data_file">Upload Data</label>
                    <input type="file" class="form-control-file" id="data_file" name="data_file">
                    <br>
                <a class="btn btn-info btn-sm" href="#" id="download_template">
                        <span class="btn-label">
                            <i class="fa fa-download"></i>
                        </span>
                        Download Template Data
                </a>
                
                </div>
                <div class="form-group">
                    <textarea name="ulasan" id="ulasan">
                        &lt;p&gt;This is some sample content.&lt;/p&gt;
                    </textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
     

           
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/19.1.1/classic/ckeditor.js"></script>
    <script>
           ClassicEditor
        .create( document.querySelector( '#ulasan' ) )
        .catch( error => {
            console.error( error );
        } );
</script>

<script>
var download_button = $('#download_template');

download_button.click(function (e) {
    e.preventDefault();
    var type=$('#graph_type').val();
    if(type=="Garis"){
        var download_url="<?php echo e(route('data.downloadTemplate',['Garis'])); ?>";
    }else if(type=="Batang"){
        var download_url="<?php echo e(route('data.downloadTemplate',['Batang'])); ?>";
    }else if(type=="pie_chart"){
        var download_url="<?php echo e(route('data.downloadTemplate',['pie_chart'])); ?>";
    }
   

    $.ajax({
        type: 'GET',
        url: download_url,
        success: function (filepath) {
        console.log(filepath);
        window.open(filepath);
        },
        error: function (err) {
            alert('gagal download');
            }
        });
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\APP DEVELOPMENT\web\SeudiaData\resources\views/backend/data_management/input_data_form.blade.php ENDPATH**/ ?>