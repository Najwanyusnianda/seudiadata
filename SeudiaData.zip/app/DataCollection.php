<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataCollection extends Model
{
    //
}
