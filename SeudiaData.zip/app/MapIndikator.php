<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MapIndikator extends Model
{
    //
    protected $fillable =['subject_id','indikator','ulasan','data','title','subtitle'];
}
