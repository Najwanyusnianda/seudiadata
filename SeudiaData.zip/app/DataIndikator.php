<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataIndikator extends Model
{
    //
    protected $fillable =['subject_id','indikator','ulasan','data','title','subtitle','graph_type'];
}
